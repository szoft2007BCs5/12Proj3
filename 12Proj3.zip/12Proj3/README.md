# 12Proj3 CSÓKOLOOOM DOKTOR UUUUR
Ricsi, Patrik, Kevin
https://docs.google.com/document/d/1nNEY_1wy-ELtJZ76-0WZT9EN03h-zWXISyRN_i8PiIY/edit?usp=sharing

RICSI EZ KELL: https://prod.liveshare.vsengsaas.visualstudio.com/join?7D786146ABDBF2D97E05076DDD2696DA9FA0
Mi a terv Ricsi? Struktúrát ide:

Projekt

|-> html

|-> css

|-> js

|-> source (audio + data)
